package com.example.idolwiki.model.auth.form;

import lombok.Getter;

@Getter
public class LoginForm {
    private String id;
    private String password;
}
