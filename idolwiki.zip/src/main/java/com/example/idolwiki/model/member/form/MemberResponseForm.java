package com.example.idolwiki.model.member.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberResponseForm {
    private String name;
    private String img;
}
