package com.example.idolwiki.model.member.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberViewForm {
    private String name;
    private String img;
}
