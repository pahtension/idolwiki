package com.example.idolwiki.model.groups.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GroupSimpleForm {
    private int seq;
    private String name;
    private String img;
}
